#ifndef POSITION
#define POSITION

struct  Position
{
	int x;
	int y;
	Position(int x,int y)
	{
		this->x=x;
		this->y=y;
	}

};

#endif // !POSITION